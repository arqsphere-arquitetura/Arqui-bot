import os
import json
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes

# Carregar mensagens de configuração
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

TOKEN = os.getenv("TELEGRAM_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[InlineKeyboardButton("📚 Ver Ebooks", callback_data="ebooks")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(config["welcome_message"], reply_markup=reply_markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "ebooks":
        with open("data/ebooks.txt", "r", encoding="utf-8") as f:
            ebooks = f.read()
        await query.edit_message_text(text=f"📚 Lista de Ebooks:\n\n{ebooks}")

def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button))

    app.run_polling()

if __name__ == "__main__":
    main()
