import json
import telebot

# Carrega as mensagens do config.json
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

BOT_TOKEN = "COLOQUE_SEU_TOKEN_AQUI"
bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(message, config["start_message"])

@bot.message_handler(commands=["menu"])
def menu(message):
    bot.reply_to(message, config["menu_message"])

bot.polling()
