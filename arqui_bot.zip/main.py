import os
import json
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Carregar configurações
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

WELCOME_MSG = config["welcome"]
MENU_OPTIONS = config["menu"]

# Função inicial
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[opt] for opt in MENU_OPTIONS]
    reply_markup = ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    await update.message.reply_text(WELCOME_MSG, reply_markup=reply_markup)

# Resposta do menu
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if text in MENU_OPTIONS:
        await update.message.reply_text(f"Você escolheu: {text}\n(Responda com conteúdo relacionado)")
    else:
        await update.message.reply_text("Não entendi, escolha uma opção do menu.")

def main():
    TOKEN = os.getenv("TELEGRAM_TOKEN")
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    app.run_polling()

if __name__ == "__main__":
    main()
